package mcjty.lostcities.dimensions.world.terrain.lost.data;

public class FountainData {

    public static Level[] FOUNTAINS = new Level[]
            {
                    new Level(new String[]{
                            "" +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "      xxxx      " +
                                    "      xWWx      " +
                                    "      xWWx      " +
                                    "      xxxx      " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                "
                    }),
                    new Level(new String[]{
                            "" +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "       xx       " +
                                    "      xWWx      " +
                                    "     xWWWWx     " +
                                    "     xWWWWx     " +
                                    "      xWWx      " +
                                    "       xx       " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                "
                    }),
                    new Level(new String[]{
                            "" +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "      xxxx      " +
                                    "      xWWx      " +
                                    "      xWWx      " +
                                    "      xxxx      " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                ",
                            "" +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "      :  :      " +
                                    "                " +
                                    "                " +
                                    "      :  :      " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                ",
                            "" +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "      :  :      " +
                                    "                " +
                                    "                " +
                                    "      :  :      " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                ",
                            "" +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "      xxxx      " +
                                    "      x  x      " +
                                    "      x  x      " +
                                    "      xxxx      " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                " +
                                    "                "
                    })
            };
}
